import os
import random
import numpy as np
import cv2
import torch.nn.functional as F
import torch

# from train_segsam import seg_sam
from torch.utils.data import Dataset
from util.common import hwc_to_chw, read_img


def augment(imgs=[], size=256, edge_decay=0., only_h_flip=False):
	H, W, _ = imgs[0].shape
	Hc, Wc = [size, size]

	# simple re-weight for the edge

	if random.random() < Hc / H * edge_decay:
		Hs = 0 if random.randint(0, 1) == 0 else H - Hc
	else:
		Hs = random.randint(0, H-Hc)

	if random.random() < Wc / W * edge_decay:
		Ws = 0 if random.randint(0, 1) == 0 else W - Wc
	else:
		Ws = random.randint(0, W-Wc)

	for i in range(len(imgs)):
		imgs[i] = imgs[i][Hs:(Hs+Hc), Ws:(Ws+Wc), :]

	# horizontal flip
	if random.randint(0, 1) == 1:
		for i in range(len(imgs)):
			imgs[i] = np.flip(imgs[i], axis=1)

	if not only_h_flip:
		# bad data augmentations for outdoor
		rot_deg = random.randint(0, 3)
		for i in range(len(imgs)):
			imgs[i] = np.rot90(imgs[i], rot_deg, (0, 1))
			
	return imgs


def check_image_size(x,size=256):
	# NOTE: for I2I test
	_, _, h, w = x.size()
	mod_pad_h = (size - h % size)
	mod_pad_w = (size - w % size)

	# mod_pad_h = (256 - h % self.window_size) % 256
	# mod_pad_w = (256 - w % self.window_size) % 256
	x = F.pad(x, (0, mod_pad_w, 0, mod_pad_h), 'reflect')
	return x


def test(imgs=[], size=256):

	for i in range(len(imgs)):
		imgs[i] = cv2.copyMakeBorder(imgs[i], 26, 26, 74,74, borderType=cv2.BORDER_REFLECT_101)
	# (512,768)
	H, W, _ = imgs[0].shape
	Hc, Wc = [size, size]
	imgs_new=[]
	for i in range(len(imgs)):
		for j in range(2):
			for k in range(3):
				imgs_new.append(imgs[i][j*Hc : (j+1)*Hc, k*Wc : (k+1)*Wc, :])
	#print(len(imgs_new))
	return imgs_new

def align(imgs=[], size=256):
	H, W, _ = imgs[0].shape
	Hc, Wc = [size, size]

	Hs = (H - Hc) // 2
	Ws = (W - Wc) // 2
	for i in range(len(imgs)):
		imgs[i] = imgs[i][Hs:(Hs+Hc), Ws:(Ws+Wc), :]
	# for i in range(len(imgs)):
	# 	imgs[i] = cv2.resize(imgs[i], (256, 256))
	# print(len(imgs))
	return imgs

class PairLoader1(Dataset):
	def __init__(self, data_dir, sub_dir, mode, size=256, edge_decay=0, only_h_flip=False):
		assert mode in ['train', 'valid', 'test']

		self.mode = mode
		self.size = size
		self.edge_decay = edge_decay
		self.only_h_flip = only_h_flip

		self.root_dir = os.path.join(data_dir, sub_dir)
		self.img_names = sorted(os.listdir(os.path.join(self.root_dir, 'hazy')))
		self.img_num = len(self.img_names)

	def __len__(self):
		return self.img_num

	def __getitem__(self, idx):
		cv2.setNumThreads(0)
		cv2.ocl.setUseOpenCL(False)

		# read image, and scale [0, 1] to [-1, 1]
		img_name = self.img_names[idx]
		img_name1 =img_name[:4]+'.jpg'
		source_img = read_img(os.path.join(self.root_dir, 'hazy', img_name)) * 2 - 1
		target_img = read_img(os.path.join(self.root_dir, 'GT', img_name)) * 2 - 1
		# print('GT', os.path.join(self.root_dir, 'GT', img_name1))
		
		if self.mode == 'train':
			[source_img, target_img] = augment([source_img, target_img], self.size, self.edge_decay, self.only_h_flip)

		if self.mode == 'valid':
			[source_img, target_img] = align([source_img, target_img], self.size)

		return {'source': hwc_to_chw(source_img), 'target': hwc_to_chw(target_img), 'filename': img_name}


class PairLoader(Dataset):
	def __init__(self, data_dir, sub_dir, mode, size=256, edge_decay=0, only_h_flip=False):
		assert mode in ['train', 'valid', 'test']

		self.mode = mode
		self.size = size
		self.edge_decay = edge_decay
		self.only_h_flip = only_h_flip

		self.root_dir = os.path.join(data_dir, sub_dir)
		self.img_names = sorted(os.listdir(os.path.join(self.root_dir, 'hazy')))
		self.img_num = len(self.img_names)

	def __len__(self):
		return self.img_num

	def __getitem__(self, idx):
		cv2.setNumThreads(0)
		cv2.ocl.setUseOpenCL(False)

		# read image, and scale [0, 1] to [-1, 1]
		img_name = self.img_names[idx]
		img_name1 = img_name[:4] + '.png'
		#img_name2 = img_name[:10] + 'c.jpg'

		#print('hazy',os.path.join(self.root_dir, 'hazy', img_name))
		source_img = read_img(os.path.join(self.root_dir, 'hazy', img_name)) * 2 - 1
		target_img = read_img(os.path.join(self.root_dir, 'GT', img_name)) * 2 - 1
		# dehazed_img = read_img(os.path.join(self.root_dir, 'dehazed', img_name)) * 2 - 1

		if self.mode == 'train':
			[source_img, target_img, ] = augment([source_img, target_img], self.size,
															self.edge_decay, self.only_h_flip)

		if self.mode == 'valid':
			[source_img, target_img] = align([source_img, target_img], self.size)

		source_img = hwc_to_chw(source_img)
		target_img = hwc_to_chw(target_img)
		dehazed_img = hwc_to_chw(source_img)

		return {'source': source_img, 'target': target_img, 'dehazed': dehazed_img, 'filename': img_name}


class PairLoader_new(Dataset):
	def __init__(self, data_dir, sub_dir, mode, size=256, edge_decay=0, only_h_flip=False):
		assert mode in ['train', 'valid', 'test']

		self.mode = mode
		self.size = size
		self.edge_decay = edge_decay
		self.only_h_flip = only_h_flip

		self.root_dir = os.path.join(data_dir, sub_dir)
		self.img_names = sorted(os.listdir(os.path.join(self.root_dir, 'hazy')))
		self.img_num = len(self.img_names)

	def __len__(self):
		return self.img_num

	def __getitem__(self, idx):
		cv2.setNumThreads(0)
		cv2.ocl.setUseOpenCL(False)

		# read image, and scale [0, 1] to [-1, 1]
		img_name = self.img_names[idx]
		img_name1 = img_name[:4] + '.jpg'
		source_img = read_img(os.path.join(self.root_dir, 'hazy', img_name)) * 2 - 1
		target_img = read_img(os.path.join(self.root_dir, 'GT', img_name1)) * 2 - 1
		# target_img = read_img(os.path.join(self.root_dir, 'GT', img_name)) * 2 - 1

		if self.mode == 'train':
			[source_img, target_img] = augment([source_img, target_img], self.size, self.edge_decay, self.only_h_flip)

		if self.mode == 'valid':
			[source_img, target_img] = align([source_img, target_img], self.size)
		a=[]
		b=[]
		if self.mode == 'test':
			#[source_img, target_img] = test([source_img, target_img], self.size)
			#datas = test([source_img, target_img], self.size)
			a = test([source_img, target_img], self.size)[5]
			b = test([source_img, target_img], self.size)[11]

		return {'source': hwc_to_chw(a), 'target': hwc_to_chw(b), 'filename': img_name}
		#return {'source': hwc_to_chw(datas[0]), 'target': hwc_to_chw(datas[6]), 'filename': img_name}

class PairLoader_seg(Dataset):
	def __init__(self, data_dir, sub_dir, mode, size=256, edge_decay=0, only_h_flip=False):
		assert mode in ['train', 'valid', 'test']

		self.mode = mode
		self.size = size
		self.edge_decay = edge_decay
		self.only_h_flip = only_h_flip

		self.root_dir = os.path.join(data_dir, sub_dir)
		self.img_names = sorted(os.listdir(os.path.join(self.root_dir, 'hazy')))
		self.img_num = len(self.img_names)

	def __len__(self):
		return self.img_num

	def __getitem__(self, idx):
		cv2.setNumThreads(0)
		cv2.ocl.setUseOpenCL(False)

		# read image, and scale [0, 1] to [-1, 1]
		img_name = self.img_names[idx]
		img_name2 = img_name[:10] + 'c.jpg'
		img_name1 = img_name[:3] + 'GT.png'
		img_name3 = img_name[:4] + '.jpg'

		#print('hazy',os.path.join(self.root_dir, 'hazy', img_name))
		source_img_orl = read_img(os.path.join(self.root_dir, 'hazy', img_name)) * 2 - 1
		target_img = read_img(os.path.join(self.root_dir, 'GT', img_name3)) * 2 - 1
		# dehazed_img = read_img(os.path.join(self.root_dir, 'dehazed', img_name)) * 2 - 1



		#print('GT', os.path.join(self.root_dir, 'GT', img_name))
		#target_img = read_img(os.path.join(self.root_dir, 'GT', img_name)) * 2 - 1

		if self.mode == 'train':
			[source_img, target_img] = augment([source_img_orl, target_img], self.size, self.edge_decay, self.only_h_flip)


		if self.mode == 'valid':
			[source_img, target_img] = align([source_img, target_img], self.size)

		source_img = hwc_to_chw(source_img)
		target_img = hwc_to_chw(target_img)

		dehazed_img = hwc_to_chw(source_img_orl)


		# seg_features=seg_sam(torch.tensor(target_img).unsqueeze(0).cuda())

		# return {'source': source_img, 'target': target_img, 'seg_features': seg_features,'filename': img_name}

		# return {'source': source_img, 'target': target_img, 'filename': img_name}
		return {'source': source_img, 'target': target_img, 'dehazed': dehazed_img, 'filename': img_name}


class SingleLoader(Dataset):
	def __init__(self, root_dir):
		self.root_dir = root_dir
		self.img_names = sorted(os.listdir(self.root_dir))
		self.img_num = len(self.img_names)

	def __len__(self):
		return self.img_num

	def __getitem__(self, idx):
		cv2.setNumThreads(0)
		cv2.ocl.setUseOpenCL(False)

		# read image, and scale [0, 1] to [-1, 1]
		img_name = self.img_names[idx]
		img = read_img(os.path.join(self.root_dir, img_name)) * 2 - 1

		return {'img': hwc_to_chw(img), 'filename': img_name}
