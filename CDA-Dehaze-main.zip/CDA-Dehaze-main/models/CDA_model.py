﻿import numpy as np
import torch
from .base_model import BaseModel, VGGNet
from . import networks
from .patchnce import PatchNCELoss
import util.util as util
import torch.nn as nn
from torch.fft import fft2, fftshift, ifft2, ifftshift
import cv2
# pretrained VGG16 module set in evaluation mode for feature extraction
vgg = VGGNet().cuda().eval()


class CDAModel(BaseModel):
    """ This class implements CDA-Dehaze model

    The code borrows heavily from the PyTorch implementation of CycleGAN, CUT and CWR
    https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix
    https://github.com/taesungp/contrastive-unpaired-translation
    https://github.com/JunlinHan/CWR
    """
    @staticmethod
    def modify_commandline_options(parser, is_train=True):
        """  Configures options specific for CUT model
        """
        parser.add_argument('--lambda_GAN', type=float, default=1.0, help='weight for GAN loss：GAN(G(X))')
        parser.add_argument('--lambda_NCE', type=float, default=1.0, help='weight for NCE loss: NCE(G(X), X)')
        parser.add_argument('--lambda_IDT', type=float, default=5.0, help='weight for NCE loss: IDT(G(Y), Y)')
        parser.add_argument('--nce_idt', type=util.str2bool, nargs='?', const=True, default=True, help='use NCE loss for identity mapping: NCE(G(Y), Y))')
        parser.add_argument('--nce_layers', type=str, default='0,5,9,13,17', help='compute NCE loss on which layers')
        parser.add_argument('--nce_includes_all_negatives_from_minibatch',
                            type=util.str2bool, nargs='?', const=True, default=False,
                            help='(used for single image translation) If True, include the negatives from the other samples of the minibatch when computing the contrastive loss. Please see models/patchnce.py for more details.')
        parser.add_argument('--netF', type=str, default='mlp_sample', choices=['sample', 'reshape', 'mlp_sample'], help='how to downsample the feature map')
        parser.add_argument('--netF_nc', type=int, default=256)
        parser.add_argument('--nce_T', type=float, default=0.07, help='temperature for NCE loss')
        parser.add_argument('--num_patches', type=int, default=256, help='number of patches per layer')
        parser.add_argument('--flip_equivariance',
                            type=util.str2bool, nargs='?', const=True, default=False,
                            help="Enforce flip-equivariance as additional regularization. It's used by FastCUT, but not CDA-Dehaze")

        parser.set_defaults(pool_size=0)  # no image pooling

        opt, _ = parser.parse_known_args()

        parser.set_defaults(nce_idt=True, lambda_NCE=1.0)

        return parser

    def __init__(self, opt):
        BaseModel.__init__(self, opt)

        # specify the training losses you want to print out.
        # The training/test scripts will call <BaseModel.get_current_losses>
        self.loss_names = ['G_GAN', 'D_real', 'D_fake', 'G', 'NCE',  'perceptual']
        self.visual_names = ['real_A', 'fake_B', 'real_B']
        self.nce_layers = [int(i) for i in self.opt.nce_layers.split(',')]

        if opt.nce_idt and self.isTrain:
            self.loss_names += ['NCE_Y']
            self.visual_names += ['idt_B']

        if self.isTrain:
            # self.model_names = ['G', 'F', 'D']
            self.model_names = ['G', 'F', 'D','G_T']
        else:  # during test time, only load G
            self.model_names = ['G']

        # define networks (both generator and discriminator)
        self.netG = networks.define_G(opt.input_nc, opt.output_nc, opt.ngf, opt.netG, opt.normG, not opt.no_dropout, opt.init_type, opt.init_gain, opt.no_antialias, opt.no_antialias_up, self.gpu_ids, opt)
        self.netF = networks.define_F(opt.input_nc, opt.netF, opt.normG, not opt.no_dropout, opt.init_type, opt.init_gain, opt.no_antialias, self.gpu_ids, opt)

        self.netG_T = networks.define_G(opt.input_nc, opt.output_nc, opt.ngf, opt.netG, opt.normG, not opt.no_dropout,
                                      opt.init_type, opt.init_gain, opt.no_antialias, opt.no_antialias_up, self.gpu_ids,
                                      opt)

        if self.isTrain:
            self.netD = networks.define_D(opt.output_nc, opt.ndf, opt.netD, opt.n_layers_D, opt.normD, opt.init_type, opt.init_gain, opt.no_antialias, self.gpu_ids, opt)

            # define loss functions
            self.criterionGAN = networks.GANLoss(opt.gan_mode).to(self.device)
            self.criterionNCE = []

            for nce_layer in self.nce_layers:
                self.criterionNCE.append(PatchNCELoss(opt).to(self.device))

            self.criterionIdt = torch.nn.L1Loss().to(self.device)
            self.optimizer_G = torch.optim.Adam(self.netG.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2))
            self.optimizer_D = torch.optim.Adam(self.netD.parameters(), lr=opt.lr, betas=(opt.beta1, opt.beta2))
            self.optimizers.append(self.optimizer_G)
            self.optimizers.append(self.optimizer_D)

    def data_dependent_initialize(self, data):
        """
        The feature network netF is defined in terms of the shape of the intermediate, extracted
        features of the encoder portion of netG. Because of this, the weights of netF are
        initialized at the first feedforward pass with some input images.
        Please also see PatchSampleF.create_mlp(), which is called at the first forward() call.
        """
        self.set_input(data)
        bs_per_gpu = self.real_A.size(0) // max(len(self.opt.gpu_ids), 1)
        self.real_A = self.real_A[:bs_per_gpu]
        self.real_B = self.real_B[:bs_per_gpu]
        self.forward()                     # compute fake images: G(A)
        if self.opt.isTrain:
            self.compute_D_loss().backward()                  # calculate gradients for D
            self.compute_G_loss().backward()                   # calculate graidents for G
            if self.opt.lambda_NCE > 0.0:
                self.optimizer_F = torch.optim.Adam(self.netF.parameters(), lr=self.opt.lr, betas=(self.opt.beta1, self.opt.beta2))
                self.optimizers.append(self.optimizer_F)

    def optimize_parameters(self):
        # forward
        self.forward()

        # update D
        self.set_requires_grad(self.netD, True)
        self.optimizer_D.zero_grad()
        self.loss_D = self.compute_D_loss()
        self.loss_D.backward()
        self.optimizer_D.step()

        # update G
        self.set_requires_grad(self.netD, False)
        self.set_requires_grad(self.netG_T, False)

        self.optimizer_G.zero_grad()
        if self.opt.netF == 'mlp_sample':
            self.optimizer_F.zero_grad()
        self.loss_G = self.compute_G_loss()
        self.loss_G.backward()
        self.optimizer_G.step()
        if self.opt.netF == 'mlp_sample':
            self.optimizer_F.step()

    def set_input(self, input):
        """Unpack input data from the dataloader and perform necessary pre-processing steps.
        Parameters:
            input (dict): include the data itself and its metadata information.
        The option 'direction' can be used to swap domain A and domain B.
        """
        AtoB = self.opt.direction == 'AtoB'
        self.real_A = input['A' if AtoB else 'B'].to(self.device)
        self.real_B = input['B' if AtoB else 'A'].to(self.device)
        self.image_paths = input['A_paths' if AtoB else 'B_paths']
        self.neck =fusion_neck()
    def forward(self):
        """Run forward pass; called by both functions <optimize_parameters> and <test>."""
        self.real = torch.cat((self.real_A, self.real_B), dim=0) if self.opt.nce_idt and self.opt.isTrain else self.real_A
        if self.opt.flip_equivariance:
            self.flipped_for_equivariance = self.opt.isTrain and (np.random.random() < 0.5)
            if self.flipped_for_equivariance:
                self.real = torch.flip(self.real, [3])

        self.fake = self.netG(self.real)[2]

        self.fake_B = self.fake[:self.real_A.size(0)]
        if self.opt.nce_idt:
            self.idt_B = self.fake[self.real_A.size(0):]


    def compute_D_loss(self):
        """Calculate GAN loss for the discriminator"""
        fake = self.fake_B.detach()
        # Fake; stop backprop to the generator by detaching fake_B
        pred_fake = self.netD(fake)
        self.loss_D_fake = self.criterionGAN(pred_fake, False).mean()      # LS_GAN MSE loss
        # Real
        self.pred_real = self.netD(self.real_B)
        loss_D_real = self.criterionGAN(self.pred_real, True)
        self.loss_D_real = loss_D_real.mean()

        # combine loss and calculate gradients
        self.loss_D = (self.loss_D_fake + self.loss_D_real) * 0.5
        return self.loss_D

    def compute_G_loss(self):
        """Calculate GAN and NCE loss for the generator"""
        fake = self.fake_B
        # First, G(A) should fake the discriminator
        if self.opt.lambda_GAN > 0.0:
            pred_fake = self.netD(fake)
            self.loss_G_GAN = self.criterionGAN(pred_fake, True).mean() * self.opt.lambda_GAN
        else:
            self.loss_G_GAN = 0.0

        if self.opt.lambda_NCE > 0.0:
            self.loss_NCE = self.calculate_NCE_loss(self.real_A, self.fake_B)    # input & generated
        else:
            self.loss_NCE, self.loss_NCE_bd = 0.0, 0.0

        if self.opt.nce_idt and self.opt.lambda_NCE > 0.0:
            self.loss_NCE_Y = 0
            loss_NCE_both = (self.loss_NCE + self.loss_NCE_Y)
            self.loss_idt = self.criterionIdt(self.idt_B, self.real_B) * self.opt.lambda_IDT       # G(Y) & clear w.CUT/ w.o. FastCUT
        else:
            loss_NCE_both = self.loss_NCE

        self.loss_perceptual = self.perceptual_loss(self.real_A, self.fake_B, self.real_B) * 0.0002     

        self.loss_distill = self.distill_loss(self.real_A) * 0.1

        # self.loss_preserve = self.preserve_loss(self.real_B)

        self.loss_G = self.loss_G_GAN  +self.loss_idt + loss_NCE_both + self.loss_perceptual + self.loss_distill #+self.loss_preserve
        # self.loss_G = self.loss_G_GAN  + self.loss_perceptual + self.loss_distill  # +self.loss_preserve

        # print(self.loss_G,self.loss_distill)
        return self.loss_G


    def perceptual_loss(self, x, y, z):
        # c = torch.nn.MSELoss()
        c = torch.nn.L1Loss()

        norm = Normalize(2)
        x = norm(torch.abs(torch.fft.fft2(x, dim=(-2, -1))))
        y = norm(torch.abs(torch.fft.fft2(y, dim=(-2, -1))))
        z = norm(torch.abs(torch.fft.fft2(z, dim=(-2, -1))))

        fx1, fx2, fx3 = vgg(x)      # hazy  extract
        fy1, fy2, fy3 = vgg(y)      # dehazed
        fz1, fz2, fz3 = vgg(z)      # clear

        m1 = c(fz1, fy1) / c(fx1, fy1)
        m2 = c(fz2, fy2) / c(fx2, fy2)
        m3 = c(fz3, fy3) / c(fx3, fy3)

        loss = 0.4 * m1 + 0.6 * m2 + m3
        # print('loss',loss)
        return loss

    def MagnitudeLoss(self, restored, ground_truth):
        # 计算恢复图像和真值图像的 FFT
        restored_fft = torch.fft.fft2(restored, dim=(-2, -1))
        ground_truth_fft = torch.fft.fft2(ground_truth, dim=(-2, -1))

        # 提取相位

        restored_phase = torch.abs(restored_fft)
        ground_truth_phase = torch.abs(ground_truth_fft)

        # restored_phase = torch.angle(restored_fft)
        # ground_truth_phase = torch.angle(ground_truth_fft)
        # 计算相位差异
        phase_difference = restored_phase - ground_truth_phase
        # diff_fft = restored_fft-ground_truth_fft

        # 计算相位差异的平均 L1 损失
        loss = torch.mean(torch.abs(phase_difference))
        # loss = torch.mean(torch.abs(diff_fft))

        return loss

    def PhaseLoss(self, restored, ground_truth):
        # 计算恢复图像和真值图像的 FFT
        restored_fft = torch.fft.fft2(restored, dim=(-2, -1))
        ground_truth_fft = torch.fft.fft2(ground_truth, dim=(-2, -1))

        # 提取相位

        # restored_phase = torch.abs(restored_fft)
        # ground_truth_phase = torch.abs(ground_truth_fft)

        restored_phase = torch.angle(restored_fft)
        ground_truth_phase = torch.angle(ground_truth_fft)
        # 计算相位差异
        phase_difference = restored_phase - ground_truth_phase
        # diff_fft = restored_fft-ground_truth_fft

        # 计算相位差异的平均 L1 损失
        loss = torch.mean(torch.abs(phase_difference))
        # loss = torch.mean(torch.abs(diff_fft))

        return loss


    def distill_loss(self, x):
        # c = torch.nn.MSELoss()
        c = torch.nn.L1Loss()

        feat_T = self.netG_T(x)      # hazy  extract
        feat_S = self.netG(x)

        loss1 = self.MagnitudeLoss(feat_T[2],feat_S[2])
        # loss2 = self.PhaseLoss(feat_T[2],feat_S[2])*0.4
        #loss2 = self.MagnitudeLoss(feat_T[1],feat_S[1])*0.1
        #loss3 = self.MagnitudeLoss(feat_T[0],feat_S[0])*0.1
        # loss2 = c(feat_T[2], feat_S[2])*2
        loss3 = c(feat_T[1], feat_S[1])
        loss4 = c(feat_T[0], feat_S[0])

        #loss2=histogram_alignment_loss(feat_S[2]*0.5+0.5,feat_T[2]*0.5+0.5)*50
        # print('1 2 3 4',loss2,loss3,loss4)

        loss =  loss1 + loss3 +loss4
        #
        return loss


    def calculate_NCE_loss(self, src, tgt):
        n_layers = len(self.nce_layers)     # CUT: RGB,1,2(downsampling),1,5(resblock)
        feat_q = self.netG(tgt, self.nce_layers, encode_only=True)

        if self.opt.flip_equivariance and self.flipped_for_equivariance:      # Fast CUT (Cycle-GAN default)
            feat_q = [torch.flip(fq, [3]) for fq in feat_q]

        feat_k = self.netG_T(src, self.nce_layers, encode_only=True)               # feature
        feat_k_pool, sample_ids = self.netF(feat_k, self.opt.num_patches, None)  # MLP 256 patch
        feat_q_pool, _ = self.netF(feat_q, self.opt.num_patches, sample_ids)     # MLP

        total_nce_loss = 0.0
        for f_q, f_k, crit, nce_layer in zip(feat_q_pool, feat_k_pool, self.criterionNCE, self.nce_layers):
            loss = crit(f_q, f_k) * self.opt.lambda_NCE
            total_nce_loss += loss.mean()

        return total_nce_loss / n_layers



class Normalize(nn.Module):

    def __init__(self, power=2):
        super(Normalize, self).__init__()
        self.power = power

    def forward(self, x):
        norm = x.pow(self.power).sum(1, keepdim=True).pow(1. / self.power)
        out = x.div(norm + 1e-7)
        return out

def compute_histogram(image, bins=256, range=(0, 1)):
    """
    在 GPU 上计算图像的直方图
    :param image: 输入图像 (Tensor, shape: [C, H, W] 或 [H, W])
    :param bins: 直方图的 bin 数量
    :param range: 像素值范围
    :return: 归一化的直方图 (Tensor, shape: [bins])
    """
    if image.dim() == 3:  # 如果是多通道图像，转换为灰度图
        image = torch.mean(image, dim=0)  # 取均值作为灰度图
    image = image.flatten()  # 展平为 1D 张量
    hist = torch.histc(image, bins=bins, min=range[0], max=range[1])  # 计算直方图
    hist = hist / hist.sum()  # 归一化
    return hist


def sort_histogram(hist):
    """
    在 GPU 上对直方图按高度从大到小排序，返回排序后的直方图和索引
    :param hist: 直方图 (Tensor, shape: [bins])
    :return: sorted_hist (Tensor), sorted_indices (Tensor)
    """
    sorted_hist, sorted_indices = torch.sort(hist, descending=True)  # 从大到小排序
    return sorted_hist, sorted_indices


def monotonic_decreasing_function(sorted_hist):
    """
    在 GPU 上生成单调递减函数，最大值为1，最小值为0
    :param sorted_hist: 排序后的直方图 (Tensor, shape: [bins])
    :return: 单调递减函数 (Tensor, shape: [bins])
    """
    max_val = sorted_hist[0]
    min_val = sorted_hist[-1]
    monotonic_func = (sorted_hist - min_val) / (max_val - min_val + 1e-8)  # 归一化到[0, 1]
    return monotonic_func


def histogram_alignment_loss(output_image, target_image, bins=256):
    """
    在 GPU 上计算直方图对齐损失
    :param output_image: 网络输出图像 (Tensor, shape: [C, H, W] 或 [H, W])
    :param target_image: 真值图像 (Tensor, shape: [C, H, W] 或 [H, W])
    :param bins: 直方图的 bin 数量
    :return: 加权损失值 (Tensor)
    """
    # 计算直方图

    target_hist = compute_histogram(target_image, bins)
    output_hist = compute_histogram(output_image, bins)

    # 对真值直方图排序
    sorted_target_hist, sorted_indices = sort_histogram(target_hist)

    # 按照真值直方图的排序方式重新排列输出直方图
    sorted_output_hist = output_hist[sorted_indices]

    # 生成单调递减函数
    monotonic_func = monotonic_decreasing_function(sorted_target_hist)

    # 计算加权差值
    diff = torch.abs(sorted_output_hist - sorted_target_hist)
    weighted_diff = diff * monotonic_func  # 使用单调递减函数加权

    # 返回加权差值的均值作为损失
    loss = torch.mean(weighted_diff)
    return loss

############################## neck
class FrequencyDecomposer(nn.Module):
    """支持4D输入(BCHW)的频域分解"""

    def __init__(self, low_ratio=0.15):
        super().__init__()
        self.low_ratio = low_ratio

    def create_mask(self, h, w, device):
        """创建4D兼容的频域掩码"""
        mask = torch.zeros((1, 1, h, w), device=device)  # 添加BC维度
        center_h, center_w = h // 2, w // 2
        radius = int(min(h, w) * self.low_ratio)
        mask[..., center_h - radius:center_h + radius,
        center_w - radius:center_w + radius] = 1
        return mask

    def forward(self, x):
        # x形状: (B, C, H, W)
        B, C, H, W = x.shape

        # FFT变换
        f = fft2(x, dim=(-2, -1))
        f_shifted = fftshift(f, dim=(-2, -1))

        # 创建可学习掩码
        mask = self.create_mask(H, W, x.device)
        mask_low = mask * (1 + 0.1 * torch.randn(1, device=x.device))
        mask_high = 1 - mask_low

        # 频域分解（保持4D形状）
        F_low = mask_low * f_shifted
        F_high = mask_high * f_shifted

        # 逆变换
        f_low = ifftshift(F_low, dim=(-2, -1))
        f_high = ifftshift(F_high, dim=(-2, -1))
        x_low = torch.abs(ifft2(f_low, dim=(-2, -1)))
        x_high = torch.abs(ifft2(f_high, dim=(-2, -1)))

        return x_low, x_high


class RKHSConstraint(nn.Module):
    """支持4D输入的RKHS约束"""

    def __init__(self, kernel='gaussian', sigma=1.0):
        super().__init__()
        self.kernel = kernel
        self.sigma = nn.Parameter(torch.tensor(sigma))  # 可学习sigma

    def pairwise_distance(self, x, y):
        """4D输入的距离计算"""
        # 输入形状: (B, C, H, W)
        x_flat = x.flatten(start_dim=1)  # (B, C*H*W)
        y_flat = y.flatten(start_dim=1)

        x_norm = (x_flat ** 2).sum(dim=1, keepdim=True)  # (B, 1)
        y_norm = (y_flat ** 2).sum(dim=1, keepdim=True)  # (B, 1)
        dist = x_norm + y_norm.t() - 2 * torch.mm(x_flat, y_flat.t())  # (B, B)
        return torch.clamp(dist, 0.0, None)

    def gaussian_kernel(self, x, y):
        """批量处理的高斯核"""
        d = self.pairwise_distance(x, y)
        return torch.exp(-d / (2 * self.sigma ** 2 + 1e-6))

    def forward(self, feat_gen, feat_gt):
        """4D输入的MMD计算"""
        K_XX = self.gaussian_kernel(feat_gen, feat_gen)
        K_YY = self.gaussian_kernel(feat_gt, feat_gt)
        K_XY = self.gaussian_kernel(feat_gen, feat_gt)

        # 排除对角线元素
        mmd = (K_XX.sum() - torch.diag(K_XX).sum()) / (K_XX.shape * (K_XX.shape - 1)) + \
              (K_YY.sum() - torch.diag(K_YY).sum()) / (K_YY.shape * (K_YY.shape - 1)) - \
              2 * K_XY.mean()
        return mmd


class WienerKhinchinProcessor(nn.Module):
    """4D输入的维纳-辛钦处理器"""

    def autocorrelation(self, x):
        """批量自相关计算"""
        # x形状: (B, C, H, W)
        fft_x = fft2(x, dim=(-2, -1))
        S = torch.abs(fft_x) ** 2  # 功率谱
        R = torch.abs(ifft2(S, dim=(-2, -1)))  # (B, C, H, W)
        return R

    def style_content_separation(self, x):
        """批量风格/内容分离"""
        B, C, H, W = x.shape
        R = self.autocorrelation(x)  # (B, C, H, W)

        # 批量SVD分解
        R_flat = R.view(B, C, -1)  # (B, C, H*W)
        style_comps = []
        content_comps = []
        for b in range(B):
            U, S, V = torch.svd(R_flat[b])
            style_comp = (U[:, :32] @ torch.diag_embed(S[:32]) @ V[:, :32].t())
            content_comp = R_flat[b] - style_comp
            style_comps.append(style_comp.view(1, C, H, W))
            content_comps.append(content_comp.view(1, C, H, W))

        return torch.cat(style_comps, dim=0), torch.cat(content_comps, dim=0)

class fusion_neck(nn.Module):
    def __init__(self):
        super().__init__()
        # 原有StyleGAN2生成器
        #self.generator = StyleGAN2Generator()

        # 新增模块
        self.freq_decompose = FrequencyDecomposer()
        self.wiener_processor = WienerKhinchinProcessor()
        #self.rkhs_constraint = RKHSConstraint(sigma=5.0)

        # 自适应融合层
        self.fusion = nn.Conv2d(12, 3, kernel_size=3, padding=1)

    def forward(self, x):
        # 原始生成流程
        #gen_img = self.generator(x)

        # 频率解耦
        low_freq, high_freq = self.freq_decompose(x)

        # 维纳-辛钦分解
        R = self.wiener_processor.autocorrelation(x)
        style_comp, content_comp = self.wiener_processor.style_content_separation(R)

        # 特征融合
        fused = self.fusion(torch.cat([low_freq, high_freq,
                                       content_comp, style_comp], dim=1))

        return fused
